
import java.util.Scanner;

public class DiophantineSolver {
    public static int gcdExtended(int a, int b, int[] xy) {
        if (b == 0) {
            xy[0] = 1;
            xy[1] = 0;
            return a;
        }
        int[] xy1 = new int[2];
        int d = gcdExtended(b, a % b, xy1);
        xy[0] = xy1[1];
        xy[1] = xy1[0] - (a / b) * xy1[1];
        return d;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Nhập a: ");
        int a = sc.nextInt();
        System.out.print("Nhập b: ");
        int b = sc.nextInt();
        System.out.print("Nhập c: ");
        int c = sc.nextInt();

        int[] xy = new int[2];
        int d = gcdExtended(a, b, xy);
        if (c % d != 0) {
            System.out.println("Phương trình vô nghiệm");
        } else {
            xy[0] *= c / d;
            xy[1] *= c / d;
            System.out.println("Nghiệm riêng: x = " + xy[0] + ", y = " + xy[1]);
        }
    }
}
