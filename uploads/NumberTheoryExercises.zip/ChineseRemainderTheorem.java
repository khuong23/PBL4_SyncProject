
import java.util.Scanner;

public class ChineseRemainderTheorem {
    public static int[] extendedGCD(int a, int b) {
        if (b == 0) return new int[]{a, 1, 0};
        int[] vals = extendedGCD(b, a % b);
        int d = vals[0], x = vals[2], y = vals[1] - (a / b) * vals[2];
        return new int[]{d, x, y};
    }

    public static long crt(int[] a, int[] m) {
        long M = 1;
        for (int mi : m) M *= mi;

        long x = 0;
        for (int i = 0; i < a.length; i++) {
            long Mi = M / m[i];
            int[] inv = extendedGCD((int) Mi, m[i]);
            x += a[i] * Mi * inv[1];
        }
        return (x % M + M) % M;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Nhập số phần tử k: ");
        int k = sc.nextInt();
        int[] a = new int[k];
        int[] m = new int[k];
        System.out.println("Nhập danh sách a:");
        for (int i = 0; i < k; i++) a[i] = sc.nextInt();
        System.out.println("Nhập danh sách m:");
        for (int i = 0; i < k; i++) m[i] = sc.nextInt();

        System.out.println("Nghiệm của hệ là: " + crt(a, m));
    }
}
