
import java.util.Scanner;

public class ModularExponentiation {
    public static long modExp(long a, long b, long n) {
        long result = 1;
        a = a % n;
        while (b > 0) {
            if ((b & 1) == 1) result = (result * a) % n;
            a = (a * a) % n;
            b >>= 1;
        }
        return result;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Nhập a: ");
        long a = sc.nextLong();
        System.out.print("Nhập b: ");
        long b = sc.nextLong();
        System.out.print("Nhập n: ");
        long n = sc.nextLong();
        System.out.println("Kết quả: " + modExp(a, b, n));
    }
}
