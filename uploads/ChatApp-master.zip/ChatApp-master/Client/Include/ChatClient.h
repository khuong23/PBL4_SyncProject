//g++ Client/Src/*.cpp -IClient/Include -o client.exe -lws2_32 -pthread
//g++ Server/Src/*.cpp -IServer/Include -o server.exe -lws2_32 -pthread

