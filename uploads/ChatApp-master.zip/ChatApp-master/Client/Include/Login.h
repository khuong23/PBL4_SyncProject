#pragma once
#include <winsock2.h>
#include <string>
using namespace std;

string showLoginForm(SOCKET sock);









