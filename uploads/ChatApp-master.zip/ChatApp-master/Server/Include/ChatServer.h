#pragma once
#include <map>
#include <mutex>
#include <vector>
#include <thread>
#include <iostream>
#include <algorithm>
#include <winsock2.h>
using namespace std;


void handleClient(SOCKET client);


